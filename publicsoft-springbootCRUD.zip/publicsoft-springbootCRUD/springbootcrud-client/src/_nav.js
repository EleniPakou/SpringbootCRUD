export default {
  items: [
    {
      name: 'HelloWorld',
      url: '/HelloWorld',
      icon: 'icon-calendar'
    },
    {
      name: 'Persons',
      url: '/persons',
      icon: 'icon-calendar'
    },
    {
      name: 'Suppliers',
      url: '/suppliers',
      icon: 'icon-calendar'
    }
  ]
}
