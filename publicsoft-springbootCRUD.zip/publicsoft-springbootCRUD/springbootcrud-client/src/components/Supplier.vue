<template>
  <el-dialog type="warning" title="Supplier Data" :visible="visible" :modal="true"
             :close-on-click-modal="false"
             :close-on-press-escape="false" :modal-append-to-body="false" :show-close="false" width="75%"
             @close="clearValidation">

    <el-card>
      <el-form ref="supplierForm" :model="supplier" :rules="rules" label-position="top">

        <el-row :gutter="20">
          <!-- LEFT COLUMN -->
          <el-col :span="12">

            <el-form-item label="Enter First Name"
                          prop="firstName">
              <el-input v-model="supplier.firstName"
                        placeholder="First Name">
              </el-input>
            </el-form-item>

            <el-form-item label="Enter Last Name"
                          prop="lastName">
              <el-input v-model="supplier.lastName"
                        placeholder="Last Name">
              </el-input>
            </el-form-item>

            <el-form-item label="Enter Company Name"
                          prop="companyName">
              <el-input v-model="supplier.companyName"
                        placeholder="Company Name">
              </el-input>
            </el-form-item>

            <el-form-item label="Enter VAT Number"
                          prop="vatNumber">
              <el-input v-model="supplier.vatNumber"
                        placeholder="VAT Number">
              </el-input>
            </el-form-item>

            <el-form-item label="Enter IRS Office"
                          prop="irsOffice">
              <el-input v-model="supplier.irsOffice"
                        placeholder="IRS Office">
              </el-input>
            </el-form-item>

          </el-col>

          <!-- RIGHT COLUMN -->
          <el-col :span="12">

            <el-form-item label="Enter Address"
                          prop="address">
              <el-input v-model="supplier.address"
                        placeholder="Address">
              </el-input>
            </el-form-item>

            <el-form-item label="Enter ZIP Code"
                          prop="zipCode">
              <el-input v-model="supplier.zipCode"
                        placeholder="ZIP Code">
              </el-input>
            </el-form-item>

            <el-form-item label="Enter City"
                          prop="city">
              <el-input v-model="supplier.city"
                        placeholder="City">
              </el-input>
            </el-form-item>

            <el-form-item label="Enter Country"
                          prop="country">
              <el-input v-model="supplier.country"
                        placeholder="Country">
              </el-input>
            </el-form-item>

          </el-col>
        </el-row>

      </el-form>

      <el-row>
        <el-col style="text-align: right">
          <el-button type="success"
                     icon="fa fa-save"
                     @click="save"> Save </el-button>

          <el-button type="danger"
                     icon="fa fa-remove"
                     @click="confirmDelete"
                     :disabled="!isDeletable"> Delete </el-button>
        </el-col>
      </el-row>
    </el-card>

    <div slot="footer" class="dialog-footer card-footer">
      <el-button type="warning"
                 icon="el-icon-back"
                 @click="cancel"> Back </el-button>
    </div>

  </el-dialog>
</template>

<script src="./SupplierVM.js"></script>
